#include <stdlib.h>
#include <iostream>

using namespace std ;

class produit
{
public:

    unsigned int NumeroProduit;
	double Prix ;
	int essai;
	int statut ;

	produit();
	~produit();

	produit(unsigned int numero , double prix );






};
